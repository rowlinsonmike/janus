<h1 align="center">
  <br>
  <img src="assets/janus.jpeg" alt="logo" width="400"/>
  <br>
 Janus
  <br>
</h1>

<h4 align="center">A CLI tool for securely managing your passwords with a local encrypted file.</h4>

<p align="center">
  <a href="#features">Features</a> •
  <a href="#why-choose-this-cli-over-saas-solutions">Why</a> •
  <a href="#install">Install</a> •
  <a href="#usage">Usage</a> •
  <a href="#security-note">Security Note</a> •
</p>

## Features

- **Secure Storage**: Passwords are encrypted using AES-256-GCM
- **Local Storage**: All data is stored locally
- **Clipboard Integration**: Passwords are copied to the clipboard when retrieved
- **Service Management**: Easily add, update, delete, and list services and their associated credentials.

## Why Choose This CLI Over SaaS Solutions

- **Privacy**: Your passwords are stored locally.
- **Control**: You have complete control over your data
- **No Subscription Fees**: No monthly fees
- **Simplicity**: A straightforward interface

## Install

1. Ensure you have Python installed on your system.
2. Install the required dependencies:
   ```bash
   pip install typer cryptography pyperclip
   ```

## Usage

### Add a Password

To add a new password for a service:

```bash
python password_manager.py add <service> <username>
```

You will be prompted to enter the password and the master encryption key.

### Update a Password

To update an existing password:

```bash
python password_manager.py update <service> <username>
```

You will be prompted to enter the new password and the master encryption key.

### Delete a Password

To delete a password for a service:

```bash
python password_manager.py delete <service>
```

You will be prompted to enter the master encryption key.

### Retrieve a Password

To retrieve a password for a service:

```bash
python password_manager.py retrieve <service>
```

The password will be copied to your clipboard. You will be prompted to enter the master encryption key.

### List All Services

To list all available services:

```bash
python password_manager.py list-services
```

You will be prompted to enter the master encryption key.

## Security Note

- Always use a strong master encryption key to protect your passwords.
- Regularly back up your encrypted password file to prevent data loss.
